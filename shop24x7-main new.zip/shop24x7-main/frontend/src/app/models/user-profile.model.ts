export interface IUserProfile{
    firstname:String;
    lastname:String;
    email:String;
    phone:String;
    interests:String;
    address:String;
}
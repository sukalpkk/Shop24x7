export interface IRegistrationFormData{
    register_first_name:String,
    register_last_name:String,
    register_email:String,
    register_password:String,
    register_confirm_password:String
}

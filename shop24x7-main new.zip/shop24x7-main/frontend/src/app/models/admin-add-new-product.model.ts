export interface IAdminAddNewProduct{
    productname:String;
    department:String;
    price:String;
    discountprice:String;
    productimage:String;
    productdescription:String;
    checkbox:String
}
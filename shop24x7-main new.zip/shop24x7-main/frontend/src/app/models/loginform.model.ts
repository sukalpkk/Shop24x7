export interface ILoginResponse{
    details:ILoginFormData[];
}
export interface ILoginFormData{
    email:String,
    password:String
}

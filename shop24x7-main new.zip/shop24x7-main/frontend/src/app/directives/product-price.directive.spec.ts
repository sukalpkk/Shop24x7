import { ProductPriceDirective } from './product-price.directive';

describe('ProductPriceDirective', () => {
  it('should create an instance', () => {
    const directive = new ProductPriceDirective();
    expect(directive).toBeTruthy();
  });
});
